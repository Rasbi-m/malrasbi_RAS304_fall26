# Design references

Checked October 23, 2026.

- [Microchip Nano hardware guide](https://ww1.microchip.com/downloads/aemDocuments/documents/MCU08/ProductDocuments/UserGuides/PIC18F57Q43-Curiosity-Nano-HW-UserGuide-DS40002186B.pdf)
- [PAM8302 amplifier connections](https://learn.adafruit.com/adafruit-pam8302-mono-2-5w-class-d-audio-amplifier/pinouts)
- [DRV2605L connections](https://learn.adafruit.com/adafruit-drv2605-haptic-controller-breakout/pinouts)
- [DRV2605L QT reference circuit](https://github.com/adafruit/Adafruit-DRV2605-PCB)
- [PAM8302 reference circuit](https://github.com/adafruit/Adafruit-PAM8302-Mono-Amplifier-PCB)
- [LM7805 regulator datasheet](https://www.ti.com/lit/ds/symlink/lm340.pdf)
